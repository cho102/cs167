name: Cindy Ho
email: cho102@ucr.edu
netID: cho102
student ID: 862151318

